-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 17, 2017 at 11:57 PM
-- Server version: 5.6.37-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `levera13_readingfun`
--

-- --------------------------------------------------------

--
-- Table structure for table `api`
--

CREATE TABLE `api` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `url` varchar(128) NOT NULL,
  `key` varchar(64) NOT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `api`
--

INSERT INTO `api` (`id`, `name`, `url`, `key`, `isDefault`, `active`) VALUES
(5, 'google', 'https://www.googleapis.com/books/v1/volumes', 'AIzaSyB9hggeAJWYRXv9FhmsedHot_AC8MiWbg8', 1, 1),
(6, 'amazon', 'https://www.amazon.com/dp/', 'readi01c-20', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `badges`
--

CREATE TABLE `badges` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL,
  `points` int(32) NOT NULL,
  `badge_img` varchar(128) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `badges`
--

INSERT INTO `badges` (`id`, `name`, `title`, `points`, `badge_img`, `active`) VALUES
(4, 'badge_1', 'Badge 1', 100, 'badge_1.png', 1),
(5, 'badge_2', 'Badge 2', 200, 'badge_2.png', 1),
(6, 'badge_3', 'Badge 3', 220, 'badge_3.png', 1),
(7, 'badge_4', 'Badge 4', 700, 'badge_4.png', 1),
(8, 'badge_5', 'Badge 5', 1000, 'badge_5.png', 1),
(9, 'badge_6', 'Badge 6', 1300, 'badge_6.png', 1),
(10, 'badge_7', 'Badge 7', 1500, 'badge_7.png', 1),
(11, 'badge_8', 'Badge 8', 1800, 'badge_8.png', 1),
(12, 'badge_9', 'Badge 9', 2000, 'badge_9.png', 1),
(13, 'badge_10', 'Badge 10', 2002, 'badge_10.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `author` varchar(128) NOT NULL,
  `isbn` varchar(32) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `isbn`, `active`) VALUES
(1, 'Mighty, Mighty Construction Site', 'Sherri Duskey Rinker', '9781452152165', 1),
(2, 'If You Give a Mouse a Brownie', 'Laura Numeroff', '9780060275716', 1),
(3, 'Happy Birthday, Cupcake!', 'Terry Border', '9780399171604', 1),
(4, 'Please, Mr. Panda', 'Steve Antony', '9780545788922', 1),
(5, 'The 1989 World Book year book', 'Robert O. Zeleny', '9780716604891', 1),
(15, 'The Kingdom Beyond the Waves', 'Stephen Hunt', '9780007232208', 1),
(16, 'Escapement', 'Jay Lake', '9780765317094', 1),
(17, 'A Transatlantic Tunnel, Hurrah!', 'Harry Harrison', '9780575071346', 1),
(18, 'The State of Jones', 'Sally Jenkins', '9780441779246', 1),
(19, 'Animals Make Us Human', 'Temple Grandin', '9780151014897', 1),
(20, 'House of Penance', 'Peter J. Tomasi', '9781506700335', 1),
(21, 'Diary of a Wimpy Kid # 4 - Dog Days', 'Jeff Kinney', '9780810983915', 1),
(22, 'The Captain Underpants Super Collection', 'Dav Pilkey', '9780439376105', 1),
(23, 'Stink and the World\'s Worst Super-stinky Sneakers', 'Megan McDonald', '9780763628345', 1),
(24, 'Dreams of Joy', 'Lisa See', '1408826119', 1),
(25, 'The Curious Incident of the Dog in the Night-Time', 'Mark Haddon', '0307371565', 1),
(26, 'The Drifter', 'Christine Lennon', '9780062457578', 1),
(27, 'The Help', 'Kathryn Stockett', '0399155341', 1),
(28, 'On Gold Mountain', 'Lisa See', '1101910089', 1),
(29, 'The Giving Tree', 'Shel Silverstein', '0061965103', 1),
(30, 'Notes from the Underground', 'Fyodor Dostoyevsky', '3736802579', 1),
(31, 'Falling Up', 'Shel Silverstein', '0001857177', 1),
(32, 'Did I Ever Tell You How Lucky You Are?', 'Seuss', '0385379331', 1),
(34, 'The Autobiography of Malcolm X', 'Malcolm X', '1101967803', 1),
(35, 'The Eleventh Commandment', 'Jeffrey Archer', '1447203003', 1),
(36, 'The Adventures of Tom Sawyer', 'Mark Twain', 'UVA:X000311246', 1),
(37, 'Data Mining: Concepts and Techniques', 'Jiawei Han', '9780123814807', 1),
(38, 'The Help', 'Kathryn Stockett', '0399585400', 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'readers', 'Readers');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `points`
--

CREATE TABLE `points` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL,
  `points` int(2) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `points`
--

INSERT INTO `points` (`id`, `name`, `title`, `points`, `active`) VALUES
(2, 'signup', 'Signup', 120, 0),
(3, 'read', 'Per Minute Reading', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `readers_books`
--

CREATE TABLE `readers_books` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `duration` int(2) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `readers_books`
--

INSERT INTO `readers_books` (`id`, `user_id`, `book_id`, `duration`, `date`) VALUES
(13, 7, 16, 32, '0000-00-00'),
(14, 7, 17, 34, '0000-00-00'),
(15, 7, 18, 44, '0000-00-00'),
(17, 9, 5, 43, '0000-00-00'),
(18, 7, 19, 21, '0000-00-00'),
(19, 9, 20, 21, '0000-00-00'),
(20, 9, 21, 34, '0000-00-00'),
(21, 9, 22, 12, '0000-00-00'),
(22, 7, 23, 12, '0000-00-00'),
(23, 7, 24, 23, '0000-00-00'),
(24, 7, 25, 30, '0000-00-00'),
(25, 15, 24, 30, '0000-00-00'),
(26, 15, 26, 12, '0000-00-00'),
(27, 7, 27, 23, '2017-03-03'),
(29, 7, 15, 10, '2017-03-13'),
(30, 7, 15, 30, '2017-03-13'),
(31, 7, 15, 9, '2017-03-13'),
(32, 7, 15, 20, '2017-03-13'),
(33, 7, 5, 20, '2017-03-13'),
(34, 7, 28, 30, '2017-03-15'),
(35, 15, 29, 23, '2017-03-18'),
(36, 17, 30, 120, '2017-03-18'),
(37, 18, 31, 32, '2017-03-18'),
(38, 18, 32, 23, '2017-03-18'),
(40, 15, 34, 150, '2017-03-20'),
(41, 15, 35, 30, '2017-03-22'),
(42, 15, 29, 60, '2017-03-22'),
(43, 7, 36, 90, '2017-03-24'),
(44, 7, 34, 32, '2017-03-24'),
(45, 7, 37, 43, '2017-04-01'),
(46, 7, 38, 45, '2017-04-25'),
(47, 7, 38, 20, '2017-05-27'),
(48, 7, 23, 30, '2017-10-13');

-- --------------------------------------------------------

--
-- Table structure for table `readers_points`
--

CREATE TABLE `readers_points` (
  `id` int(11) NOT NULL,
  `user_id` int(20) NOT NULL,
  `point_id` int(11) NOT NULL,
  `points` int(3) NOT NULL DEFAULT '0',
  `readers_book_id` int(11) DEFAULT NULL,
  `added_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `readers_points`
--

INSERT INTO `readers_points` (`id`, `user_id`, `point_id`, `points`, `readers_book_id`, `added_on`) VALUES
(6, 7, 3, 0, 12, '0000-00-00'),
(7, 7, 3, 0, 13, '0000-00-00'),
(8, 7, 3, 0, 14, '0000-00-00'),
(9, 7, 3, 32, 15, '0000-00-00'),
(11, 9, 3, 0, 17, '0000-00-00'),
(12, 7, 3, 0, 18, '0000-00-00'),
(13, 9, 3, 0, 19, '0000-00-00'),
(14, 9, 3, 0, 20, '0000-00-00'),
(15, 9, 3, 0, 21, '0000-00-00'),
(16, 7, 3, 0, 22, '0000-00-00'),
(17, 5, 0, 40, NULL, '0000-00-00'),
(18, 5, 0, 50, NULL, '0000-00-00'),
(19, 7, 3, 0, 23, '0000-00-00'),
(20, 7, 3, 0, 24, '0000-00-00'),
(21, 15, 3, 0, 25, '0000-00-00'),
(22, 15, 3, 0, 26, '0000-00-00'),
(23, 7, 3, 0, 27, '2017-10-03'),
(24, 7, 3, 0, 28, '1969-12-31'),
(25, 7, 3, 0, 29, '2017-03-13'),
(26, 7, 3, 0, 30, '2017-03-13'),
(27, 7, 3, 0, 31, '2017-03-13'),
(28, 7, 3, 0, 32, '2017-03-13'),
(30, 7, 3, 0, 34, '2017-03-15'),
(31, 5, 0, 10, NULL, '0000-00-00'),
(32, 15, 3, 0, 35, '2017-03-18'),
(33, 17, 3, 0, 36, '2017-03-18'),
(34, 18, 3, 0, 37, '2017-03-18'),
(35, 18, 3, 0, 38, '2017-03-18'),
(36, 19, 3, 0, 39, '2017-03-16'),
(37, 15, 3, 0, 40, '2017-03-20'),
(38, 15, 3, 0, 41, '2017-03-22'),
(39, 15, 3, 0, 42, '2017-03-22'),
(40, 9, 0, 50, NULL, '0000-00-00'),
(41, 15, 0, 700, NULL, '0000-00-00'),
(42, 7, 0, 50, NULL, '0000-00-00'),
(43, 7, 3, 0, 43, '2017-03-24'),
(44, 7, 3, 0, 44, '2017-03-24'),
(45, 7, 3, 0, 45, '2017-04-01'),
(46, 7, 3, 0, 46, '2017-04-25'),
(47, 7, 3, 0, 47, '2017-05-27'),
(48, 7, 3, 0, 48, '2017-10-13');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `street` varchar(64) NOT NULL,
  `city` varchar(32) NOT NULL,
  `state` varchar(4) NOT NULL,
  `zip` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `name`, `street`, `city`, `state`, `zip`) VALUES
(1, 'Western Illinois University', '1 University Circle', 'Macomb', 'IL', 61455),
(2, 'The Dalton School', '108 East 89th Street', 'New York', 'NY', 10128),
(4, 'California Elementary School', '3232 California Street', 'Costa Mesa', 'CA', 92626),
(5, 'Michigan State University', '220 Trowbridge Rd', 'East Lansing', 'MI', 48824),
(6, 'The University of Chicago', '5801 South Ellis Avenue', 'Chicago', 'IL', 60637),
(7, 'Macomb High School', 'Macomb', 'Macomb', 'IL', 61455),
(8, 'Edison Elementary School', '521 South Pearl Street', 'Macomb', 'IL', 61455),
(9, 'Macomb Junior High School', '1525 South Johnson Street', 'Macomb', 'IL', 61455),
(10, 'St Paul Catholic School', '322 West Washington Street', 'Macomb', 'IL', 61455);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(8) NOT NULL,
  `name` varchar(32) NOT NULL,
  `value` int(2) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `active`) VALUES
(1, 'show_readers', 1, 1),
(2, 'show_video', 1, 1),
(3, 'show_school', 1, 1),
(4, 'show_book', 1, 1),
(5, 'no_of_readers', 12, 1),
(6, 'no_of_books', 12, 1),
(7, 'no_of_latest_books', 12, 1),
(8, 'no_of_schools', 12, 1),
(9, 'show_latest_book', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` date NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `avatar` varchar(64) DEFAULT NULL,
  `gender` varchar(8) DEFAULT NULL,
  `address_id` varchar(128) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `apt` varchar(8) DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `school_id` int(8) DEFAULT '-1',
  `library_id` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `in_city` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `avatar`, `gender`, `address_id`, `address`, `apt`, `city`, `state`, `zip`, `birthdate`, `school_id`, `library_id`, `phone`, `in_city`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$rj2dNEtfA2tBzrjw.8VyNuA4Uhkd3INgo/KL9kbVRwrM6/VSSIw8C', '', 'admin@admin.com', '', NULL, NULL, NULL, '2017-02-26', 1511632645, 1, 'Admin', 'istrator', 'boy-9.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '12345', '0', 1),
(5, '::1', 'fimaruf@outlook.com', '$2y$08$UNJz2bP6.cCuR5e9wU446uMXeiTrc5/7f0dtzL.0KgQZKnzAPda1m', NULL, 'fimaruf@outlook.com', NULL, NULL, NULL, NULL, '0000-00-00', NULL, 1, 'Fakhrul', 'Maruf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 1),
(7, '::1', 'fimaruf@gmail.com', '$2y$08$zeGW9NYJCtLSUgBabPfTq.owRZxBrnkOsBp8wL3gZDDzkcQKR4Eka', NULL, 'fimaruf@gmail.com', NULL, '7eVipVG6PR961v4c-9bwKu73434b7b7f8d6ae9bc', 1489871434, NULL, '2017-02-26', 1513055290, 1, 'Md Fakhrul', 'Islam', 'boy-11.png', 'male', 'Eic5MTEgTiBDaGFybGVzIFN0LCBNYWNvbWIsIElMIDYxNDU1LCBVU0E', '911 North Charles Street', '17', 'Macomb', 'IL', 61455, '1982-03-11', 1, '54321', '(309) 569-1974', 1),
(9, '::1', 'netexbd@gmail.com', '$2y$08$P31MydWyo1eOaJX6ZMwxb.r63narw5eiRBVQrJg.P52BLhj.gwP0G', NULL, 'netexbd@gmail.com', NULL, NULL, NULL, NULL, '2017-02-26', 1488151969, 1, 'Fakhrul', 'Maruf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '654321', NULL, 1),
(15, '::1', 'rumana@gmail.com', '$2y$08$NLkEbj9BiJLrQs5FEAtPNOFSR9669k9LgL2iUuGkr2qLY15WD3k8a', NULL, 'rumana@gmail.com', NULL, '7eVipVG6PR961v4c-9bwKu73434b7b7f8d6ae9bc', 1489871434, NULL, '2017-03-05', 1490422485, 1, 'Rumana', 'Afroz', 'girl-10.png', 'female', 'ChIJpXRA1q_w4IcRr-Z7yjr5rFw', '923 West Carroll Street', '1', 'Macomb', 'IL', 61455, '1990-03-18', 5, '', '(309) 569-7867', 1),
(16, '::1', 'bil@gmai.com', '$2y$08$/p9Ab/om.P0X5R/hZ6VnLu/GXCoabchiP6cNcwMnPUwnc0ZDtZCue', NULL, 'bil@gmai.com', NULL, NULL, NULL, NULL, '2017-03-16', NULL, 1, 'Bill', 'Gates', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1),
(17, '104.173.76.22', 'wforbes87@gmail.com', '$2y$08$6XbMRH.14T/.sj6Bf6RzqeIkbZR11sD49/QTBSj89BJDvKc8/MpKu', NULL, 'wforbes87@gmail.com', NULL, NULL, NULL, NULL, '2017-03-18', 1489867734, 1, 'Will', 'Forbes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 1),
(18, '173.240.202.205', 'leverage.infotech@gmail.com', '$2y$08$MD9tBrw.e7Ik1IX7MhTjvuwpC5Z9My8QMvcnmeM3l5IQ/wLZ39T/W', NULL, 'leverage.infotech@gmail.com', NULL, NULL, NULL, NULL, '2017-03-18', 1489872709, 1, 'Leverage', 'Infotech', 'boy-3.png', 'male', 'ChIJE4pPFl0zDogRnZ86Pn2X18k', '5681 West Madison Street', '', 'Chicago', 'IL', 60644, '1995-03-18', 4, '', '', 1),
(19, '143.43.165.139', 'mk-clemmens@wiu.edu', '$2y$08$XwY6/IYi1hc1hpGnEasrS.RltbzAt7eBoO5K2mViMuMKKIakfzSwy', NULL, 'mk-clemmens@wiu.edu', NULL, NULL, NULL, NULL, '2017-03-20', 1490222430, 1, 'Matt', 'Clemmens', 'boy-8.png', 'male', 'ChIJ9wE-t0734IcRD9WsfWrjVy8', '335 South Lafayette Street', '', 'Macomb', 'IL', 61455, '1993-09-04', 7, '43235235234', '(309) 093-4444', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(6, 5, 2),
(8, 7, 2),
(13, 9, 2),
(17, 15, 2),
(18, 16, 2),
(19, 17, 2),
(20, 18, 2),
(21, 19, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api`
--
ALTER TABLE `api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `badges`
--
ALTER TABLE `badges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `readers_books`
--
ALTER TABLE `readers_books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `readers_points`
--
ALTER TABLE `readers_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `points_id` (`point_id`),
  ADD KEY `readers_book_id` (`readers_book_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api`
--
ALTER TABLE `api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `badges`
--
ALTER TABLE `badges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `points`
--
ALTER TABLE `points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `readers_books`
--
ALTER TABLE `readers_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `readers_points`
--
ALTER TABLE `readers_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
