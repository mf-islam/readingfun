<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = array (
  'install_date' => '2017-02-11 08:42:44',
  'db' => 
  array (
    'hostname' => 'localhost',
    'username' => 'levera13_admin',
    'password' => 'Bangla1971!',
    'database' => 'levera13_readingfun',
  ),
  'integrity' => '292783dcdc556b3bbcd53f37357e30b58a24c1a1',
);
