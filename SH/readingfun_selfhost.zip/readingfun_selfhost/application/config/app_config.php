<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = array (
  'site_title' => 'Leslie F. Malpass Library',
  'site_slogan' => 'Let\'s the fun started',
  'first_name' => 'John',
  'last_name' => 'Doug',
  'admin_email' => 'fimaruf@gmail.com',
  'admin_phone' => '(309) 2999-4567',
  'address' => 'One University Circle',
  'city' => 'Macomb',
  'state' => 'IL',
  'zip' => '61455',
  'country' => 'United States',
);
