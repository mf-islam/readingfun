<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function index()
	{

	}

	public function getReaders($count = false) {
		$this->db->select('users.id, username, email, created_on, active, first_name,last_name, library_id, phone');
		$this->db->from('users');
		$this->db->join('users_groups', 'users_groups.user_id = users.id');
		$where = "active='1' AND users_groups.group_id = 2";
		$this->db->where($where);
		if ($count) {
			$this->db->limit($count);
		}

		$this->db->order_by('users.id', 'ASC');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
                
        return $query->result();
	}

	public function update_point($point_id, $data) {
		$this->db->where('id', $point_id);
		$this->db->update('points', $data);

		return true;
	}

	public function get_points() {
		$this->db->select('*');
		$this->db->from('points');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
                
        return $query->result();
	}

	public function get_badges() {
		$this->db->select('*');
		$this->db->from('badges');
		$this->db->order_by('points', 'ASC');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
                
        return $query->result();
	}

	public function setApi($data) {
		//$this->my_library->print_r($data);
		$this->db->select('*');
		$this->db->from('api');
		$this->db->where('name', $data['name']);
		$query = $this->db->get();

		if($query->num_rows() > 0) {

			$this->db->where('name', $data['name']);
			$this->db->update('api', $data);
		} else {

			$this->db->insert('api', $data);
		}

		return true;
	}

	public function saveSettings($data) {
		foreach ($data as $key => $value) {
			$this->db->select('*');
			$this->db->from('settings');
			$this->db->where('name', $key);
			$query = $this->db->get();

			if($query->num_rows() > 0) {
				$this->db->set('value', $value);
				$this->db->where('name', $key);
				$this->db->update('settings');
			} else {
				$data = array(
					'name' => $key,
					'value' => $value
				);
				$this->db->insert('settings', $data);
			}
		}

		return true;
	}

	public function getSettings() {
		$this->db->select('*');
		$this->db->from('settings');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
                
        return $query->result();
	}

	public function getApi() {
		$this->db->select('*');
		$this->db->from('api');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
                
        return $query->result();
	}

	public function update_badge($badge_id, $data) {
		$this->db->where('id', $badge_id);
		$this->db->update('badges', $data);

		return true;
	}

	public function addPointsToReader($uid, $points) {
		$data  = array(
			'user_id' => $uid,
			'points' => $points
		);

		if ($this->db->insert('readers_points', $data))
			return true;

		return false;
	}

	public function setSchool($data) {
		// check if there is available school
		$this->db->select('*');
		$this->db->from('schools');
		$where = 'name = "' . $data['name'] . '" AND city = "' . $data['city'] . '" AND zip = "' . $data['zip'] . '"';
		$this->db->where($where);
		$query = $this->db->get();

		if($query->num_rows() > 0) {
			return false;
		} else {
			if ($this->db->insert('schools', $data))
			return true;
		}
	}

	public function getSchools($order_by = false, $limit = false) {
		$this->db->select('schools.*, count(distinct(users.id)) as no_of_students, count(distinct(readers_books.book_id)) as no_of_books, IFNULL(sum(readers_books.duration), 0) as duration');
		$this->db->from('schools');
		$this->db->join('users', 'users.school_id = schools.id', 'left');
		$this->db->join('readers_books', 'readers_books.user_id = users.id', 'left');
		$this->db->group_by('schools.id');
		$this->db->order_by('name', 'ASC');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;

		$school_data = $query->result();
		
		foreach ($school_data as $key => $value) {
			$school_data[$key]->points = $points = $this->getSchoolTotalPoint($value->id, 'users.school_id');
			if ($order_by == 'points') {
				$point[$key] = $points;
			}
		}

		// sort according to order
        if ($order_by == 'points') {
        	array_multisort($point, SORT_DESC, $school_data);
        }

        //$this->my_library->print_r($school_data);

        return $school_data;
	}

	public function getSchoolTotalPoint($school_id, $group_by = false)
	{
		/*$this->db->select('(IFNULL(SUM(readers_books.duration*points.points), 0) + IFNULL(SUM(readers_points.points), 0)) as total_points');
		$this->db->from('readers_points');
		$this->db->join('points', 'points.id = readers_points.point_id', 'left');
		$this->db->join('readers_books', 'readers_books.id = readers_points.readers_book_id', 'left');
		$this->db->join('users', 'readers_books.user_id = users.id', 'left');
		$where = "users.school_id = '" . $school_id . "'";
		$this->db->where($where);
		if ($group_by) {
			$this->db->group_by($group_by, 'ASC');
		}*/
		
		$total_points = 0;
		
		// get users per school
		$this->db->select('users.id as userid');
		$this->db->from('users');
		$this->db->where('users.school_id', $school_id);
		$user_query = $this->db->get();
		
		if($user_query->num_rows() < 1) {
			return 0;
		}
		
		$arr = array_map (function($value){
			return $value['userid'];
		}, $user_query->result_array());

		if(sizeof($arr > 0)) {
			$this->load->model('readers_model');
			foreach($arr as $userid) {
				$total_points += $this->readers_model->getReadersTotalPoint($userid, false);
			}
		}
        
      	return $total_points; 
	}

	/*public function addPointsToReader($uid, $points) {

		// check if user exists
		$this->db->select('*');
		$this->db->from('readers_points');
		$where  = 'user_id = "' . $uid . '"';
		$query = $this->db->get();

		if($query->num_rows() < 1) { // no readers point available
			$data = array(
				'user_id' => $uid,
				'points' => $points
			);

			//$this->db->set('points', $points);
			$this->db->where('user_id', $uid);
			$this->db->insert('readers_points', $data);
		} else {
			$this->db->set('points', $points);
			$this->db->where('user_id', $uid);
			$this->db->update('readers_points');
		}

		return true;
	}*/
}