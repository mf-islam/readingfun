<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Books_model extends CI_Model {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function index()
	{

	}

	public function getBookInfoDb ($data) {
		$this->db->select('*');
		$this->db->from('books');
		$where = 'title="' . $data['title'] . '" or author="' . $data['author'] . '" or isbn="' . $data['isbn'] . '"';
		$this->db->where($where);
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
   
        return $query->row();
	}

	public function getLatestBooks($count, $order_by = 'id', $userid = false) {
		$this->db->select('books.*, users.id, concat(users.first_name, " ", users.last_name) as name, users.email, readers_books.*, sum(duration) as duration');
		$this->db->from('books');
		$this->db->join('readers_books', 'readers_books.book_id = books.id');
		$this->db->join('users', 'readers_books.user_id = users.id');
		if ($userid) 
		{
			$where = 'readers_books.user_id = "' . $userid . '"';
			$this->db->where($where);
		}
		$this->db->limit($count);
		$this->db->group_by('books.id');
		$this->db->order_by('readers_books.'.$order_by, 'DESC');

		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
   
   		
        return $query->result();
	}

	public function getReadersCountPerBook($book_id) {
		$this->db->select('count(distinct(readers_books.user_id)) as count');
		$this->db->from('readers_books');
		$this->db->where('book_id', $book_id);
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
   
   		
        return $query->row()->count;
	}

	public function getTotalBooksCount($userid = false) {
		$user_id = (isset($userid) ? $userid : false);
		$this->db->select('count(distinct(books.id)) as count');
		$this->db->from('books');
		if ($user_id) {
			$this->db->join('readers_books', 'readers_books.book_id = books.id');
			$where = 'readers_books.user_id = "' . $user_id . '"';
			$this->db->where($where);
		}
		$query = $this->db->get();

		return $query->row()->count;
	}

	public function getApi() {
		$this->db->select('*');
		$this->db->from('api');
		$query = $this->db->get();

		if($query->num_rows() < 1)
			return false;
                
        return $query->result_array();
	}
}