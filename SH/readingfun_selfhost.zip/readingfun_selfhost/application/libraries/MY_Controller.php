<?php

class MY_Controller extends Controller {

   function MY_Controller ()   
   {
      parent::Controller();
   }

}
