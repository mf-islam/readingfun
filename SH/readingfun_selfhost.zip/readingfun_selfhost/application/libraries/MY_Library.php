<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class MY_Library {
	public function niceDebug ($data) {
		highlight_string("<?php\n\$data =\n" . var_export($data, true) . ";\n?>");
	}

	public function print_r ($data) {
		echo '<pre>';
		print_r($data);
		echo '</pre>';
	}

	/** * Debug Helper * * Outputs the given variable(s) with formatting and location * * @access public * @param mixed variables to be output */
	function dump($callee) { 
		list($callee) = debug_backtrace(); 
		$arguments = func_get_args(); 
		$total_arguments = count($arguments); 
		echo '<fieldset style="background: #fefefe !important; border:2px red solid; padding:5px">'; 
		echo '<legend style="background:lightgrey; padding:5px;">'.$callee['file'].' @ line: '.$callee['line'].'</legend><pre>'; 
		$i = 0; 
		foreach ($arguments as $argument) { 
			echo '<br/><strong>Debug #'.(++$i).' of '.$total_arguments.'</strong>: '; 
			var_dump($argument); 
		} 
			
		echo "</pre>"; echo "</fieldset>";
	}
}