<!-- Signup form -->
<div class="events row">
  <div class="container">
    <div class="row">
    <div class="col-md-2 text-left text-danger"><h2 class="title"><?php echo $page_title; ?></h2></div>
    <div class="col-md-6"><hr></div>
    </div>
    <div class="twenty_px_height"></div>
    <div class="row">
      <span class="text-primary">Development Idea</span> ~ Justin Ehrlich, PhD<br/>
       <span class="text-primary">UI and CSS</span> ~ Paper Dashboard, www.tympanus.net<br/>
       <span class="text-primary">Some JavaScript and UI help </span> ~ Codepen.io<br/>
       <span class="text-primary">Template idea and CSS</span> ~ W3layout<br/>
       <span class="text-primary">PHP Framework</span> ~ CodeIgniter<br/>
       <span class="text-primary">UI and CSS framework</span> ~ Bootstrap<br/>
       <span class="text-primary">javascript Framework</span> ~ jQuery<br/>
       <span class="text-primary">Fronts</span> ~ Google Fonts API and FontAwsome<br/>
       <span class="text-primary">Data API (Books Information)</span> ~ Google Books and Openlibrary<br/>
       <span class="text-primary">Free badge ICON</span> ~ www.flaticon.com<br/>
    </div>
  </div>
</div>