	<!--<div class="row">
		<div class="w3_agileits_twitter_post">
			<div class="container">
				<h4>"Pellentesque habitant morbi tristique senectus et netus <a href="#">
					http://example.com</a> egestas."</h4>
			</div>
		</div>
	</div>-->
	<div class="w3layouts_copy_right row">
		<div class="container">
			<p>&copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.fimaruf.com">Md Fakhrul Islam</a> . All rights reserved&nbsp;&nbsp;|&nbsp;&nbsp;<span class="text-muted"><a href="<?php echo base_url(); ?>disclaimer">Disclaimer</span></p>
		</div>
	</div>
</div><!-- end container -->
		<script src="<?php echo base_url(); ?>assets/new/js/bootstrap.js"></script>

		<!-- //for bootstrap working -->
		<script src="<?php echo base_url(); ?>assets/new/js/custom.js"></script>

		<!--  Notifications Plugin    -->
		<script src="<?php echo base_url(); ?>assets/js/bootstrap-notify.js"></script>

		<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
		<script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>

		<!--  Date Time Picker Plugin is included in this js file -->
		<script src="<?php echo base_url(); ?>assets/js/bootstrap-datetimepicker.js"></script>

		<script type="text/javascript">
			$('.phone')

			.on('keypress', function(e) {
			  var key = e.charCode || e.keyCode || 0;
			  var phone = $(this);
			  if (phone.val().length === 0) {
			    phone.val(phone.val() + '(');
			  }
			  // Auto-format- do not expose the mask as the user begins to type
			  if (key !== 8 && key !== 9) {
			    if (phone.val().length === 4) {
			      phone.val(phone.val() + ')');
			    }
			    if (phone.val().length === 5) {
			      phone.val(phone.val() + ' ');
			    }
			    if (phone.val().length === 9) {
			      phone.val(phone.val() + '-');
			    }
			    if (phone.val().length >= 14) {
			      phone.val(phone.val().slice(0, 13));
			    }
			  }

			  // Allow numeric (and tab, backspace, delete) keys only
			  return (key == 8 ||
			    key == 9 ||
			    key == 46 ||
			    (key >= 48 && key <= 57) ||
			    (key >= 96 && key <= 105));
			})

			.on('focus', function() {
			  phone = $(this);

			  if (phone.val().length === 0) {
			    phone.val('(');
			  } else {
			    var val = phone.val();
			    phone.val('').val(val); // Ensure cursor remains at the end
			  }
			})

			.on('blur', function() {
			  $phone = $(this);

			  if ($phone.val() === '(') {
			    $phone.val('');
			  }
			});
		</script>
		<!-- Notification -->
		<script>
		$(function(){
			<?php if (isset($_SESSION['message'])): ?>
		  <?php foreach ($_SESSION['message'] as $key => $value) { ?>
		    custom.showNotification(
		      'danger', 
		      '<?php echo $value; ?>',
		      'top',
		      'center');
		  <?php } endif; ?>
		  <?php if (isset($_SESSION['error'])): ?>
		    custom.showNotification(
		      'danger', 
		      '<?php echo $_SESSION['error']; ?>',
		      'top',
		      'center');
		  <?php endif; ?>
		  <?php if (isset($_SESSION['success'])): ?>
		    custom.showNotification(
		      'success', 
		      '<?php echo $_SESSION['success']; ?>',
		      'top',
		      'center');
		  <?php endif; ?>
		  <?php if (isset($_SESSION['warning'])): ?>
		    custom.showNotification(
		      'warning', 
		      '<?php echo $_SESSION['warning']; ?>',
		      'top',
		      'center');
		  <?php endif; ?>
		});

		</script>

		<script type="text/javascript">
		    $().ready(function(){
		        // Init DatetimePicker
		        custom.initDatetimepickers();
		    });
		</script>
		<script>
		var date=new Date();
		$('#birthdate').datetimepicker({
		    useCurrent: true, //this is important as the functions sets the default date value to the current value 
		    format: 'MM/DD/YYYY',
		    maxDate: date
		});
		</script>

		<script>
		var date=new Date();
		$('.readDate').datetimepicker({
		    useCurrent: true, //this is important as the functions sets the default date value to the current value 
		    format: 'MM-DD-YYYY',
		    maxDate: date
		});
		</script>
	</body>
</html>